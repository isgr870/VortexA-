"""
Vortexa Studio - Kinematics Engine
Industry-grade Forward and Inverse Kinematics using NumPy.
Supports revolute joints with explicit axis handling and basic Jacobian IK.
"""

from __future__ import annotations

import numpy as np
from typing import List, Optional, Sequence, Dict, Any


def _rotation_matrix(axis: str, angle: float) -> np.ndarray:
    """Return 4x4 homogeneous rotation matrix about the given axis."""
    c, s = np.cos(angle), np.sin(angle)
    R = np.eye(4)
    if axis == "x":
        R[1, 1] = c
        R[1, 2] = -s
        R[2, 1] = s
        R[2, 2] = c
    elif axis == "y":
        R[0, 0] = c
        R[0, 2] = s
        R[2, 0] = -s
        R[2, 2] = c
    elif axis == "z":
        R[0, 0] = c
        R[0, 1] = -s
        R[1, 0] = s
        R[1, 1] = c
    else:
        raise ValueError(f"Unsupported joint axis: {axis}")
    return R


def _translation_matrix(length: float, axis: str = "z") -> np.ndarray:
    """Return 4x4 translation along the primary link axis (default z)."""
    T = np.eye(4)
    if axis == "x":
        T[0, 3] = length
    elif axis == "y":
        T[1, 3] = length
    else:  # z
        T[2, 3] = length
    return T


class KinematicsEngine:
    """
    Forward and inverse kinematics for serial kinematic chains described
    by the Vortexa topology format.
    """

    def __init__(self, robot_topology: Sequence[Dict[str, Any]]):
        self.topology = list(robot_topology)
        self.n_joints = sum(1 for link in self.topology if link.get("type") != "fixed")

    def _active_joints(self) -> List[Dict[str, Any]]:
        return [link for link in self.topology if link.get("type") != "fixed"]

    def forward_kinematics(self, joint_angles: Sequence[float]) -> np.ndarray:
        """
        Compute the homogeneous transformation from base to end-effector.

        Parameters
        ----------
        joint_angles : sequence of float
            Angles (radians) for each non-fixed joint in order.

        Returns
        -------
        np.ndarray
            4x4 homogeneous transformation matrix.
        """
        angles = list(joint_angles)
        transform = np.eye(4)
        angle_idx = 0

        for link in self.topology:
            link_type = link.get("type", "revolute")
            axis = link.get("axis", "z")
            length = float(link.get("length", 0.3))

            if link_type == "fixed":
                # Pure translation for fixed links
                transform = transform @ _translation_matrix(length, axis="z")
                continue

            # Revolute / continuous / prismatic
            if angle_idx >= len(angles):
                angle = 0.0
            else:
                angle = float(angles[angle_idx])
                angle_idx += 1

            if link_type in ("revolute", "continuous"):
                rot = _rotation_matrix(axis, angle)
                # Link length along the local z after rotation (standard serial chain)
                trans = _translation_matrix(length, axis="z")
                transform = transform @ rot @ trans
            elif link_type == "prismatic":
                # Prismatic: translation along the joint axis by the joint value
                # plus the nominal length
                trans = _translation_matrix(length + angle, axis=axis)
                transform = transform @ trans
            else:
                # Fallback
                transform = transform @ _translation_matrix(length)

        return transform

    def end_effector_position(self, joint_angles: Sequence[float]) -> np.ndarray:
        """Convenience: return only the 3D position of the end-effector."""
        T = self.forward_kinematics(joint_angles)
        return T[:3, 3].copy()

    def solve_ik(
        self,
        target_position: Sequence[float],
        initial_angles: Optional[Sequence[float]] = None,
        max_iters: int = 100,
        tol: float = 1e-4,
        damping: float = 0.1,
        step_size: float = 0.5,
    ) -> List[float]:
        """
        Numerical inverse kinematics using damped least-squares Jacobian.

        This is a practical industrial-grade solver for serial chains.
        It is not analytic; for high-precision work, seed with a good
        initial guess and validate the residual.
        """
        active = self._active_joints()
        n = len(active)
        if n == 0:
            return []

        if initial_angles is None:
            angles = np.zeros(n)
        else:
            angles = np.array(initial_angles, dtype=float)
            if len(angles) < n:
                angles = np.pad(angles, (0, n - len(angles)))
            angles = angles[:n]

        target = np.array(target_position, dtype=float)

        for _ in range(max_iters):
            pos = self.end_effector_position(angles)
            error = target - pos
            err_norm = np.linalg.norm(error)
            if err_norm < tol:
                break

            # Numerical Jacobian (central difference)
            J = np.zeros((3, n))
            eps = 1e-6
            for i in range(n):
                a_plus = angles.copy()
                a_minus = angles.copy()
                a_plus[i] += eps
                a_minus[i] -= eps
                J[:, i] = (self.end_effector_position(a_plus) - self.end_effector_position(a_minus)) / (2 * eps)

            # Damped least squares: J^T (J J^T + λ² I)⁻¹ error
            JJT = J @ J.T
            reg = (damping ** 2) * np.eye(3)
            try:
                delta = J.T @ np.linalg.solve(JJT + reg, error)
            except np.linalg.LinAlgError:
                delta = J.T @ error  # fallback

            angles = angles + step_size * delta

            # Simple joint limit soft clamp (optional, can be improved with real limits)
            angles = np.clip(angles, -np.pi, np.pi)

        return angles.tolist()

    def validate_fk_consistency(self, joint_angles: Sequence[float], tol: float = 1e-8) -> bool:
        """Quick self-check that repeated FK calls are deterministic."""
        T1 = self.forward_kinematics(joint_angles)
        T2 = self.forward_kinematics(joint_angles)
        return np.allclose(T1, T2, atol=tol)
