#!/usr/bin/env bash
# Vortexa Studio launcher – desktop & Termux friendly
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

echo "=================================================="
echo "  VORTEXA STUDIO v2.1 – Offline Robotics Studio"
echo "=================================================="

# Optional: create venv if desired
# python3 -m venv .venv && source .venv/bin/activate

pip install -q -r requirements.txt 2>/dev/null || true

# Start WebSocket bridge in background
echo "[*] Starting computation bridge on ws://127.0.0.1:8765 ..."
python3 server.py > server.log 2>&1 &
BRIDGE_PID=$!
echo "    Bridge PID: $BRIDGE_PID"

# Start static HTTP server for the frontend
echo "[*] Starting HTTP server on http://127.0.0.1:8080 ..."
python3 -m http.server 8080 > http.log 2>&1 &
HTTP_PID=$!
echo "    HTTP PID: $HTTP_PID"

echo ""
echo "Open in browser:  http://127.0.0.1:8080"
echo "WebSocket:        ws://127.0.0.1:8765"
echo ""
echo "Logs: server.log / http.log"
echo "Stop with: kill $BRIDGE_PID $HTTP_PID"
echo "=================================================="

# Keep script alive if desired
# wait
