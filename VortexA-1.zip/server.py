#!/usr/bin/env python3
"""
Vortexa Studio v2 - Core Asynchronous WebSocket Bridge
Industry-grade local computation server for offline robotics design.
"""

import asyncio
import json
import logging
import os
import sys
from pathlib import Path

import websockets
try:
    from websockets.asyncio.server import serve
except ImportError:
    from websockets.server import serve  # older websockets

# Ensure scripts are importable
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from scripts.kinematics_engine import KinematicsEngine
from scripts.rigidbody_dynamics import RigidBodyDynamics
from scripts.urdf_generator_api import generate_urdf
from scripts.pybullet_sim import generate_pybullet_script

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("VortexaBridge")

TEMPLATES_DIR = ROOT / "assets" / "templates"
URDF_DIR = ROOT / "urdf"
CONFIG_DIR = ROOT / "config"

# Ensure directories exist
for d in (TEMPLATES_DIR, URDF_DIR, CONFIG_DIR):
    d.mkdir(parents=True, exist_ok=True)


def load_template(template_name: str) -> dict:
    """Load a robot topology template with fallback."""
    candidates = [
        TEMPLATES_DIR / f"{template_name}.json",
        TEMPLATES_DIR / "articulated_arm.json",
    ]
    for path in candidates:
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            logger.info("Loaded template: %s", path.name)
            return data
    raise FileNotFoundError(f"No template found for '{template_name}'")


async def handle_client(websocket):
    client = websocket.remote_address
    logger.info("Client connected: %s", client)

    try:
        async for raw in websocket:
            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                await websocket.send(json.dumps({
                    "status": "error",
                    "message": "Invalid JSON payload"
                }))
                continue

            action = data.get("action")
            logger.info("Action: %s", action)

            try:
                if action == "load_template":
                    template_name = data.get("template_name", "articulated_arm")
                    template = load_template(template_name)
                    response = {
                        "status": "success",
                        "action": "load_template",
                        "template_name": template.get("name", template_name),
                        "topology": template.get("links", []),
                        "metadata": {
                            "dof": len([l for l in template.get("links", []) if l.get("type") != "fixed"]),
                            "link_count": len(template.get("links", [])),
                        }
                    }

                elif action == "compute_fk":
                    topology = data.get("topology") or load_template("articulated_arm")["links"]
                    joint_angles = data.get("joint_angles", [0.0] * 6)
                    engine = KinematicsEngine(topology)
                    pose = engine.forward_kinematics(joint_angles)
                    response = {
                        "status": "success",
                        "action": "compute_fk",
                        "end_effector_position": pose[:3, 3].tolist(),
                        "transformation_matrix": pose.tolist(),
                    }

                elif action == "compute_ik":
                    topology = data.get("topology") or load_template("articulated_arm")["links"]
                    target = data.get("target", [0.5, 0.0, 0.8])
                    initial = data.get("initial_angles")
                    engine = KinematicsEngine(topology)
                    angles = engine.solve_ik(target, initial)
                    response = {
                        "status": "success",
                        "action": "compute_ik",
                        "joint_angles": angles,
                        "target": target,
                    }

                elif action == "compute_dynamics":
                    topology = data.get("topology") or load_template("articulated_arm")["links"]
                    joint_angles = data.get("joint_angles", [0.0] * 6)
                    dyn = RigidBodyDynamics(topology)
                    mass_matrix = dyn.compute_mass_matrix(joint_angles)
                    response = {
                        "status": "success",
                        "action": "compute_dynamics",
                        "mass_matrix": mass_matrix,
                    }

                elif action == "compile_urdf":
                    topology = data.get("topology") or load_template("articulated_arm")["links"]
                    robot_name = data.get("robot_name", "vortexa_robot")
                    urdf_str = generate_urdf(topology, robot_name=robot_name)
                    out_path = URDF_DIR / f"{robot_name}.urdf"
                    out_path.write_text(urdf_str, encoding="utf-8")
                    response = {
                        "status": "success",
                        "action": "compile_urdf",
                        "urdf": urdf_str,
                        "path": str(out_path),
                    }

                elif action == "export_pybullet":
                    urdf_filename = data.get("urdf_filename", "vortexa_robot.urdf")
                    script = generate_pybullet_script(urdf_filename)
                    response = {
                        "status": "success",
                        "action": "export_pybullet",
                        "script": script,
                    }

                elif action == "health":
                    response = {
                        "status": "success",
                        "action": "health",
                        "version": "2.1.0",
                        "templates": [p.stem for p in TEMPLATES_DIR.glob("*.json")],
                    }

                else:
                    response = {
                        "status": "error",
                        "message": f"Unknown action: {action}",
                        "supported": [
                            "load_template", "compute_fk", "compute_ik",
                            "compute_dynamics", "compile_urdf", "export_pybullet", "health"
                        ]
                    }

                await websocket.send(json.dumps(response))

            except Exception as e:
                logger.exception("Error processing action %s", action)
                await websocket.send(json.dumps({
                    "status": "error",
                    "message": str(e),
                    "action": action,
                }))

    except websockets.exceptions.ConnectionClosed as e:
        logger.info("Client disconnected: %s (code=%s)", client, e.code)
    except Exception as e:
        logger.exception("Unexpected error for client %s: %s", client, e)


async def main():
    host = os.environ.get("VORTEXA_HOST", "127.0.0.1")
    port = int(os.environ.get("VORTEXA_PORT", "8765"))
    logger.info("Vortexa Studio Bridge v2.1 starting on ws://%s:%s", host, port)
    async with serve(handle_client, host, port, ping_interval=20, ping_timeout=20):
        await asyncio.Future()  # run forever


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Vortexa Bridge shut down cleanly.")
