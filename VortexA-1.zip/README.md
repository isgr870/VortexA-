# Vortexa Studio v2.1

**Portable, offline-first 3D robotics design & validation studio**

Vortexa Studio is a lightweight, local-first environment for defining robot topology, computing kinematics & dynamics, and exporting standards-compliant URDF / PyBullet artifacts. Designed to run on desktop and Android/Termux with zero cloud dependency.

## Quick Start

```bash
cd vortexa_studio
pip install -r requirements.txt
python3 server.py          # WebSocket bridge on :8765
# in another terminal
python3 -m http.server 8080
# open http://127.0.0.1:8080
```

Or use the launcher:

```bash
chmod +x launch_vortexa.sh
./launch_vortexa.sh
```

## Supported Actions (WebSocket)

| Action            | Description                              |
|-------------------|------------------------------------------|
| `health`          | Server status & available templates      |
| `load_template`   | Load robot topology JSON                 |
| `compute_fk`      | Forward kinematics                       |
| `compute_ik`      | Inverse kinematics (damped least-squares)|
| `compute_dynamics`| Approximate mass matrix                  |
| `compile_urdf`    | Generate & save compliant URDF           |
| `export_pybullet` | Generate runnable PyBullet script        |

## Architecture

- `server.py` – asyncio WebSocket computation bridge
- `scripts/kinematics_engine.py` – NumPy FK + numerical IK
- `scripts/rigidbody_dynamics.py` – mass properties & inertias
- `scripts/urdf_generator_api.py` – standards-oriented URDF export
- `scripts/pybullet_sim.py` – physics validation script generator
- `assets/templates/` – robot blueprints
- `tests/` – golden & unit tests

## Design Goals (Industry Path)

1. **Correctness first** – validated FK/IK and clean URDF
2. **Offline & portable** – works on Termux, laptops, CI
3. **Standards bridge** – excellent export into Gazebo, Isaac, MuJoCo, ROS 2
4. **Fast design loop** – topology → live kinematics → export in seconds

## Running Tests

```bash
python3 tests/test_kinematics.py
```

## License

Apache-2.0 (recommended for industrial adoption)
